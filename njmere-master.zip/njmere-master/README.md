This is a C++ implement of extracting biomedical entities and relations from raw text.
Please see the publication "A neural joint model for entity and relation extraction from biomedical text" for details.
If you have any question, pleae feel free to contact me.

Citation in BibTex:

@Article{Li2017,
author="Li, Fei and Zhang, Meishan and Fu, Guohong and Ji, Donghong",
title="A neural joint model for entity and relation extraction from biomedical text",
journal="BMC Bioinformatics",
year="2017",
volume="18",
number="1",
pages="198",
doi="10.1186/s12859-017-1609-9",
url="http://dx.doi.org/10.1186/s12859-017-1609-9"
}
